import React, { useEffect, useRef } from 'react'
import styled from 'styled-components'
import { getBucketColor } from '../rtpConfig'
import { BPS_PER_WHOLE } from 'gamba-core-v2'

const ScoreboardContainer = styled.div`
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 1000;
  pointer-events: none;
  height: 320px; /* Fixed height for 6 tiles + title on desktop */
  overflow: hidden;
  
  /* Mobile responsive adjustments */
  @media (max-width: 768px) {
    right: 5px;
    top: 20px;
    transform: none;
    height: 200px; /* Fixed height for 4 tiles + title on mobile */
    gap: 4px;
  }
  
  /* Hide on very small screens */
  @media (max-width: 480px) {
    display: none;
  }
`

const TileGrid = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  height: 100%;
  position: relative;
  
  @media (max-width: 768px) {
    gap: 4px;
  }
`

const TileSlot = styled.div<{ position: number; isTransitioning?: boolean; isMobile: boolean }>`
  position: absolute;
  width: 100%;
  transition: transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  transform: translateY(${({ position, isMobile }) => position * (isMobile ? 40 : 48)}px);
  
  ${({ isTransitioning }) => isTransitioning && `
    z-index: 10;
  `}
`

const BucketItem = styled.div<{ 
  multiplier: number;
  isActive?: boolean;
  index: number;
  isPlaceholder?: boolean;
}>`
  position: relative;
  width: 60px;
  height: 40px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 14px;
  color: white;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.8);
  transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  
  /* Mobile responsive adjustments */
  @media (max-width: 768px) {
    width: 50px;
    height: 32px;
    font-size: 12px;
    border-radius: 6px;
  }
  
  ${({ multiplier, isPlaceholder }) => {
    if (isPlaceholder) {
      return `
        /* Enhanced 3D placeholder styling */
        background: linear-gradient(135deg, 
          rgba(100, 100, 100, 0.3), 
          rgba(80, 80, 80, 0.3) 50%, 
          rgba(60, 60, 60, 0.3)
        );
        border: 2px dashed rgba(255, 255, 255, 0.2);
        
        /* Multiple shadow layers for 3D depth */
        box-shadow: 
          0 6px 12px rgba(5, 5, 15, 0.4),
          0 4px 8px rgba(8, 8, 20, 0.3),
          0 2px 4px rgba(15, 15, 30, 0.2),
          inset 0 1px 0 rgba(255, 255, 255, 0.1);
      `;
    }
    const colors = getBucketColor(multiplier);
    return `
      /* Enhanced 3D gradient backgrounds like Mines */
      background: linear-gradient(135deg, 
        ${colors.primary}, 
        ${colors.secondary} 50%, 
        ${colors.tertiary}
      );
      
      /* Multiple shadow layers for 3D depth */
      box-shadow: 
        0 6px 12px rgba(5, 5, 15, 0.4),
        0 4px 8px rgba(8, 8, 20, 0.3),
        0 2px 4px rgba(15, 15, 30, 0.2),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
        
      /* Enhanced 3D border effects */
      border: 3px solid ${colors.primary.replace('0.9)', '0.8)')};
    `;
  }}
  
  ${({ isActive }) => isActive && `
    /* Enhanced 3D active state with glow effects */
    transform: scale(1.15);
    border-color: rgba(255, 255, 0, 0.8);
    box-shadow: 
      0 8px 20px rgba(255, 215, 0, 0.6),
      0 6px 12px rgba(5, 5, 15, 0.4),
      0 4px 8px rgba(8, 8, 20, 0.3),
      0 2px 4px rgba(15, 15, 30, 0.2),
      inset 0 1px 0 rgba(255, 255, 255, 0.3);
    animation: bucketPulse 0.6s ease-out;
    
    @media (max-width: 768px) {
      transform: scale(1.1);
    }
  `}
  
  /* Enhanced 3D highlight overlay */
  &::before {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    border-radius: 10px;
    background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.3s ease;
  }
  
  ${({ isActive }) => isActive && `
    &::before {
      opacity: 1;
    }
  `}
  
  /* Enhanced 3D animation with more dramatic effects */
  @keyframes bucketPulse {
    0% {
      transform: scale(1.15);
    }
    50% {
      transform: scale(1.25);
      box-shadow: 
        0 12px 30px rgba(255, 215, 0, 0.8),
        0 8px 20px rgba(5, 5, 15, 0.4),
        0 6px 12px rgba(8, 8, 20, 0.3),
        0 4px 8px rgba(15, 15, 30, 0.2),
        inset 0 1px 0 rgba(255, 255, 255, 0.4);
    }
    100% {
      transform: scale(1.15);
    }
  }
  
  @media (max-width: 768px) {
    @keyframes bucketPulse {
      0% {
        transform: scale(1.1);
      }
      50% {
        transform: scale(1.2);
      }
      100% {
        transform: scale(1.1);
      }
    }
  }
`

const BucketIndex = styled.div`
  position: absolute;
  top: -8px;
  left: -8px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  font-size: 10px;
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid rgba(255, 255, 255, 0.3);
  
  /* Enhanced 3D styling for index badge */
  box-shadow: 
    0 3px 6px rgba(5, 5, 15, 0.6),
    0 2px 4px rgba(8, 8, 20, 0.4),
    0 1px 2px rgba(15, 15, 30, 0.3),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);
    
  /* 3D border effect */
  border: 2px solid rgba(255, 255, 255, 0.4);
  
  /* Text shadow for depth */
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.8);
  
  @media (max-width: 768px) {
    width: 16px;
    height: 16px;
    font-size: 8px;
    top: -6px;
    left: -6px;
  }
`

const ScoreboardTitle = styled.div`
  text-align: center;
  font-size: 12px;
  font-weight: bold;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 8px;
  letter-spacing: 0.5px;
  
  /* Enhanced 3D text styling */
  text-shadow: 
    0 2px 4px rgba(0, 0, 0, 0.8),
    0 1px 2px rgba(0, 0, 0, 0.6),
    1px 1px 0 rgba(255, 255, 255, 0.3);
    
  /* Subtle background for depth */
  background: linear-gradient(135deg, 
    rgba(0, 0, 0, 0.4), 
    rgba(20, 20, 30, 0.3)
  );
  padding: 4px 8px;
  border-radius: 6px;
  
  /* 3D border effect */
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: 
    0 2px 4px rgba(5, 5, 15, 0.3),
    inset 0 1px 0 rgba(255, 255, 255, 0.1);
`

interface BucketScoreboardProps {
  multipliers: number[];
  activeBuckets?: Set<number>;
  bucketHits?: Map<number, number>; // bucket index -> hit count
  recentHits?: number[]; // Array of recent bucket indices in order
}

interface TileData {
  bucketIndex: number;
  isPlaceholder: boolean;
  id: string; // Unique identifier for tracking
}

export const BucketScoreboard: React.FC<BucketScoreboardProps> = ({
  multipliers,
  activeBuckets = new Set(),
  bucketHits = new Map(),
  recentHits = []
}) => {
  const [isMobile, setIsMobile] = React.useState(false)
  const [tiles, setTiles] = React.useState<TileData[]>([])
  const [transitioning, setTransitioning] = React.useState(false)
  
  // Detect mobile screen size
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth <= 768)
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])
  
  const maxTiles = isMobile ? 4 : 6
  
  // Initialize with placeholder tiles
  useEffect(() => {
    const initialTiles: TileData[] = Array.from({ length: maxTiles }, (_, i) => ({
      bucketIndex: -1,
      isPlaceholder: true,
      id: `placeholder-${i}-${maxTiles}` // Include maxTiles in ID to force re-render on resize
    }))
    setTiles(initialTiles)
  }, [maxTiles])
  
  // Handle new bucket hits
  useEffect(() => {
    if (recentHits.length === 0) return
    
    const latestHit = recentHits[recentHits.length - 1]
    
    // Always add new hits, even if they're duplicates (remove the duplicate check)
    setTransitioning(true)
    
    // Create new tile for the bottom position
    const newTile: TileData = {
      bucketIndex: latestHit,
      isPlaceholder: false,
      id: `bucket-${latestHit}-${Date.now()}`
    }
    
    // Shift all tiles up and add new one at bottom
    setTiles(prevTiles => {
      const newTiles = [...prevTiles.slice(1), newTile]
      return newTiles
    })
    
    // Clear transitioning state after animation
    setTimeout(() => setTransitioning(false), 500)
    
  }, [recentHits])

  return (
    <ScoreboardContainer>
      <ScoreboardTitle>RECENT HITS</ScoreboardTitle>
      <TileGrid>
        {tiles.map((tile, index) => (
          <TileSlot 
            key={tile.id}
            position={index}
            isTransitioning={transitioning}
            isMobile={isMobile}
          >
            <BucketItem
              multiplier={tile.isPlaceholder ? 0 : (multipliers[tile.bucketIndex] || 0)}
              isActive={!tile.isPlaceholder && activeBuckets.has(tile.bucketIndex)}
              index={tile.bucketIndex}
              isPlaceholder={tile.isPlaceholder}
            >
              {!tile.isPlaceholder && (
                <>
                  {(multipliers[tile.bucketIndex] || 0).toFixed(2)}×
                </>
              )}
              {tile.isPlaceholder && (
                <div style={{ 
                  opacity: 0.4, 
                  fontSize: '12px',
                  color: 'rgba(255, 255, 255, 0.5)'
                }}>
                  --
                </div>
              )}
            </BucketItem>
          </TileSlot>
        ))}
      </TileGrid>
    </ScoreboardContainer>
  )
}
