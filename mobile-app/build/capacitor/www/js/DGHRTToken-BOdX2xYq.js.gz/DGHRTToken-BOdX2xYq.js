import{r as t,j as e}from"./three-D4AtYCWe.js";import{d as s,u as h,a as m,U as x,c as f,e as g,b as r,h as j,i as l,g as o,f as n}from"./index-eL7pTMGs.js";import"./react-vendor-faCf7XlP.js";import"./blockchain-C0nfa7Sw.js";import"./physics-audio-DLMfKFaI.js";const u=s.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 3rem;
  text-align: center;
  
  .token-logo {
    transition: transform 0.3s ease;
    
    &:hover {
      transform: scale(1.05);
    }
  }
  
  .subtitle {
    color: var(--text-secondary);
    font-style: italic;
    margin-top: 1rem;
    font-size: 1.2rem;
  }
  
  @media (max-width: 768px) {
    margin-bottom: 2rem;
    
    .subtitle {
      font-size: 1rem;
    }
  }
`;s.div`
  text-align: center;
  margin: 2rem 0;
  
  .coming-soon {
    font-size: 1.5rem;
    font-weight: 700;
    color: #ffd700;
    margin: 1rem 0;
  }
  
  .description {
    margin: 1rem 0;
    line-height: 1.6;
  }
`;const T=()=>{const c=m("DGHRT Token","Learn about the DGHRT Token - Our native casino token with utility, staking rewards, and governance features"),[p,a]=t.useState(!1),{currentColorScheme:i}=h();return t.useEffect(()=>{a(!0)},[]),e.jsxs(e.Fragment,{children:[c,e.jsxs(x,{$colorScheme:i,children:[e.jsx(f,{$colorScheme:i,children:"💎 $DGHRT Token 💎"}),e.jsx(g,{$colorScheme:i,children:"The Heart Token — emotional and financial heartbeat of Degen Casino"}),e.jsx(r,{$colorScheme:i,children:e.jsx(u,{children:e.jsx("img",{src:"/png/images/$DGHRT.png",alt:"DGHRT Token",className:"token-logo",style:{width:"150px",height:"150px",borderRadius:"50%",border:"3px solid #ffd700",marginBottom:"2rem"},onError:d=>{d.currentTarget.src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTUwIiBoZWlnaHQ9IjE1MCIgdmlld0JveD0iMCAwIDE1MCAxNTAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxNTAiIGhlaWdodD0iMTUwIiByeD0iNzUiIGZpbGw9InVybCgjZ3JhZGllbnQwX2xpbmVhcl8xXzEpIi8+CjxkZWZzPgo8bGluZWFyR3JhZGllbnQgaWQ9ImdyYWRpZW50MF9saW5lYXJfMV8xIiB4MT0iMCIgeTE9IjAiIHgyPSIxNTAiIHkyPSIxNTAiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KPHN0b3Agc3RvcC1jb2xvcj0iI2Q0YTU3NCIvPgo8c3RvcCBvZmZzZXQ9IjAuNSIgc3RvcC1jb2xvcj0iI2I4MzY2YSIvPgo8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNkNGE1NzQiLz4KPC9saW5lYXJHcmFkaWVudD4KPC9kZWZzPgo8dGV4dCB4PSI3NSIgeT0iODAiIGZpbGw9IndoaXRlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMjQiIGZvbnQtd2VpZ2h0PSJib2xkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj7wn5KOPC90ZXh0Pgo8L3N2Zz4K"}})})}),e.jsx(j,{$colorScheme:i,children:e.jsxs(l,{children:[e.jsxs("div",{style:{textAlign:"center"},children:[e.jsx("h3",{style:{color:"#ffd700",fontSize:"1.5rem",marginBottom:"0.5rem"},children:"🏦 Max Supply"}),e.jsx("div",{style:{fontSize:"2rem",fontWeight:"bold",color:"#fff"},children:"1B"}),e.jsx("div",{style:{opacity:.8},children:"DGHRT Tokens"})]}),e.jsxs("div",{style:{textAlign:"center"},children:[e.jsx("h3",{style:{color:"#ffd700",fontSize:"1.5rem",marginBottom:"0.5rem"},children:"⏰ Launch Date"}),e.jsx("div",{style:{fontSize:"2rem",fontWeight:"bold",color:"#fff"},children:"Q3 2026"}),e.jsx("div",{style:{opacity:.8},children:"Planned Launch"})]}),e.jsxs("div",{style:{textAlign:"center"},children:[e.jsx("h3",{style:{color:"#ffd700",fontSize:"1.5rem",marginBottom:"0.5rem"},children:"🎯 Distribution"}),e.jsx("div",{style:{fontSize:"2rem",fontWeight:"bold",color:"#fff"},children:"100%"}),e.jsx("div",{style:{opacity:.8},children:"Via Gameplay Claims"})]})]})}),e.jsxs(r,{$colorScheme:i,children:[e.jsx(o,{$colorScheme:i,children:"🚀 Get $DGHRT Tokens"}),e.jsxs(n,{$colorScheme:i,children:[e.jsx("div",{style:{textAlign:"center",fontSize:"1.5rem",fontWeight:"700",color:"#ffd700",marginBottom:"1rem"},children:"Coming Q3 2026"}),e.jsx("p",{children:"$DGHRT will be distributed 100% through gameplay. No presale, no team allocation, no VCs. Every token is earned through your devotion to the casino — claim 100 tokens weekly per lost bet."}),e.jsx("p",{children:"Once launched, you'll be able to trade $DGHRT on Raydium DEX and use it for exclusive house-edge games, governance voting, and future airdrops."})]})]}),e.jsxs(r,{$colorScheme:i,children:[e.jsx(o,{$colorScheme:i,children:"🌟 Tokenomics of Love"}),e.jsx(n,{$colorScheme:i,children:e.jsxs(l,{children:[e.jsxs("div",{children:[e.jsx("h4",{style:{color:"#ffd700",marginBottom:"0.5rem"},children:"📊 Total Supply"}),e.jsx("p",{children:"1,000,000,000 $DGHRT — a universe of possibilities, all distributed through gameplay claims"})]}),e.jsxs("div",{children:[e.jsx("h4",{style:{color:"#ffd700",marginBottom:"0.5rem"},children:"🎮 Earning Mechanism"}),e.jsx("p",{children:"Claim 100 tokens weekly per lost bet — loyalty rewards baked into code"})]}),e.jsxs("div",{children:[e.jsx("h4",{style:{color:"#ffd700",marginBottom:"0.5rem"},children:"🚫 No Presale"}),e.jsx("p",{children:"Zero team allocation, no VC tokens, no dev wallet — pure, unfiltered creation"})]}),e.jsxs("div",{children:[e.jsx("h4",{style:{color:"#ffd700",marginBottom:"0.5rem"},children:"📈 Fair Distribution"}),e.jsx("p",{children:"100% community-driven through gameplay — every tear becomes a token"})]}),e.jsxs("div",{children:[e.jsx("h4",{style:{color:"#ffd700",marginBottom:"0.5rem"},children:"🔄 Emission Schedule"}),e.jsx("p",{children:"Weekly claimable rewards based on casino activity — rewards for the faithful"})]}),e.jsxs("div",{children:[e.jsx("h4",{style:{color:"#ffd700",marginBottom:"0.5rem"},children:"💱 Trading"}),e.jsx("p",{children:"Will be tradeable on Raydium DEX post-launch — liquidity for true believers"})]})]})})]}),e.jsxs(r,{$colorScheme:i,children:[e.jsx(o,{$colorScheme:i,children:"⚡ Token Utilities"}),e.jsx(n,{$colorScheme:i,children:e.jsxs("ul",{style:{paddingLeft:"1.5rem"},children:[e.jsx("li",{children:"Bet with your soul on exclusive house-edge games that test fortune's limits"}),e.jsx("li",{children:"Unlock community access & features that reveal like hidden chambers"}),e.jsx("li",{children:"Participate in governance — $DGHRT holders vote on future games and features"}),e.jsx("li",{children:"Access to exclusive merchandise and limited edition items"}),e.jsx("li",{children:"Eligibility for future airdrops and special events"}),e.jsx("li",{children:"Premium support and early access to new game releases"}),e.jsx("li",{children:"Stake for additional rewards and platform benefits"}),e.jsx("li",{children:"Trade freely on-chain or hold like a true Degen who understands deeper meaning"})]})})]}),e.jsxs(r,{$colorScheme:i,children:[e.jsx(o,{$colorScheme:i,children:"🔗 Important Links"}),e.jsxs(n,{$colorScheme:i,children:[e.jsxs("p",{children:[e.jsx("strong",{children:"Contract Address:"})," TBD (To be deployed Q3 2026)",e.jsx("br",{}),e.jsx("strong",{children:"Network:"})," Solana (SPL Token)",e.jsx("br",{}),e.jsx("strong",{children:"Decimals:"})," 9",e.jsx("br",{}),e.jsx("strong",{children:"Creator:"})," @DegenWithHeart — Self-funded, unsponsored, building with passion"]}),e.jsx("p",{style:{marginTop:"1.5rem",fontSize:"0.9rem",opacity:.8,fontStyle:"italic"},children:"Remember: DYOR. NFA. This is not financial advice. Build is my love language — I craft digital realms from pure passion."})]})]})]})]})};export{T as default};
